import Link from 'next/link';
import './cardvoluntariados.css';

const CardVoluntariados = () => {
  
  const projetos= [
    {
      nome: 'Ajudando a trazer a felicidade',
      status: true,
    },

    {
      nome: 'A felicidade só é real se compartilhada',
      status: true,
    },
    {
      nome: 'Hamburgada do bem',
      status: false,
    },
    {
      nome: 'Libriando',
      status: false,
    },
    {
      nome: 'Projeto sorrindo',
      status: false,
    },
  ];

  return (
    <div className='cardVolunariados'>
      <div className='header-cardVoluntariados'>
        <h4>Voluntariados</h4>
        <Link href='/' className='cardVoluntariadosLink'><img src="/assets/icones/plus.png" /></Link>
      </div>
      <ul className='listaVolunatriados'>
        {projetos.map((projeto) => <li className='cardItem'>
          <div className={projeto.status ? 'projetoAtivo' : 'projetoInativo'}></div>{projeto.nome}</li>)}
      </ul>
    </div>
  )
}

export default CardVoluntariados;