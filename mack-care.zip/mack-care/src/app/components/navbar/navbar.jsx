import Link from 'next/link';

import './navbar.css';

const Navbar = () => {
	return (
			<nav className='navbar'>
				<Link href="/">
					<img src="/assets/icones/mackcare-logo.png"/>
				</Link>
				<Link href="/">
					<img src="/assets/icones/calendario.png"/>
				</Link>
				<Link href="/" >
					<img src="/assets/icones/lupa.png"/>
				</Link>
				<Link href="/perfil" >
					<img src="/assets/icones/miniatura-perfil.png"/>
				</Link>
			</nav>
      )

}

export default Navbar;