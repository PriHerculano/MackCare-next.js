export const Card = ({nmg, url, title}) => {

    return (
        <section style={{
            backgroundImage: `url(/imagem-categoria-${nmg}.jpeg)`, 
            maxWidth: 310, width: '100%', height: 310, 
            borderRadius: 60, backgroundRepeat: `no-repeat`, display: `flex`,
            alignItems: `center`, justifyContent: `center`, margin: '0 auto'
        }}>
            <a href={url} style={{paddingTop: 15, paddingBottom: 15, backgroundColor:"white", width: `100%`,
            display: "flex", alignItems: `center`, justifyContent: `center`, opacity: `70%`, textDecoration: `none`}}> 
            {title}
            </a>
        </section>
    )
}