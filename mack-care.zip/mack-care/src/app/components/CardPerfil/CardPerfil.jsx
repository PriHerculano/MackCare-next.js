import Link from 'next/link';
import './CardPerfil.css';

const PerfilFoto = () => {
  return (
    <section className='container-perfilFoto'>
      <Link  href={'/'} className='perfilGearLink'> <img  className='perfilGear' src='/assets/icones/gear.png' /></Link>
      <div className='perfilFoto'>
        <img src='./assets/foto-perfil.png' />
        <h2> Bem-vindo Mackenzista!</h2>
      </div>
    </section>
  )

}

export default PerfilFoto;