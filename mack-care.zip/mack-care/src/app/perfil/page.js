import PerfilFoto from "../components/CardPerfil/CardPerfil";
import CardVoluntariados from "../components/CardVoluntariados/CardVoluntariados";
import Navbar from "../components/navbar/navbar";
import './perfil.css';



export default function PerfilPag() {
  return (
    <div>
      <div className='navbarPerfil'>
        <Navbar />
      </div>
      <PerfilFoto />
      <div className="perfilConteudo">
        <h3>Inscrições</h3>
        <CardVoluntariados />
      </div>
    </div>
  )
}