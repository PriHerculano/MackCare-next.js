import Image from "next/image";
import Navbar from "../components/navbar/navbar";
import { Card } from "../components/cardVolum/cardVolum";
import Style from "../page.module.css";


export default function Home() {
    return (
      <div>
      <Navbar />
      <main>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <img src="/imagem-homepage-1.jpeg" alt="Descrição da imagem" style={{ width: '45%', height: 'auto' }} />
          <div className="homepage_p">
            <h2 style={{margin: 20}}>Ei, universitários!</h2>
            <p className={Style.homepage_p}>Você já pensou em como o trabalho voluntário pode fazer a diferença na vida de pessoas ao seu redor?<br></br>
            Que tal se juntar a nós e descobrir como pequenas ações podem gerar grandes mudanças</p>
          </div>
        </div>
        <div className="categorias" style={{ width: '100%', backgroundColor: "rgb(157,58,58, 0.4)", }}>
        <h1>Categorias: </h1>
        <div style={{
          display: 'grid',
          gridTemplateRows: 'repeat(2, 1fr)',
          gridTemplateColumns: 'repeat(2, 1fr)',
          gap: 8,
        }}>
          <Card title={"Crianças carentes"} url={""} nmg={1}/>
          <Card title={"Maior inclusão"} url={""} nmg={2}/>
          <Card title={"Contra a fome"} url={""} nmg={3}/>
          <Card title={"Ver mais..."} url={""} nmg={4}/>
        </div>
      </div>
      
        </main>
      </div>
    )
  }