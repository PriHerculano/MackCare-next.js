"use client"
import Homepage from './homepage/page';
import React, { useState } from 'react';

function App() {
  const [mostrarHomepage, setMostrarHomepage] = useState(false);
  const [modo, setModo] = useState('entrar');
  const [usuario, setUsuario] = useState();
  const [senha, setSenha] = useState();
  const [confirmarSenha, setConfirmarSenha] = useState();
  const [mensagem, setMensagem] = useState();

  const realizarAcao = () => {
    if (modo === 'entrar') {
      setMostrarHomepage(true);
    } else {
      setMensagem(`Criando conta com usuário ${usuario}`);
    }
  };

  const alternarModo = () => {
    setModo(modo === 'entrar' ? 'cadastrar' : 'entrar');
  };

  return (
    <div className="container_form">
      {mostrarHomepage ? (
        <Homepage />
      ) : (
          <div className="formulario">
          <img src="mack-care-logo.png" />
          <div className="box">
            <h1>{modo === 'entrar' ? 'Entrar' : 'Cadastrar'}</h1>
            <div className="input-container">
              <input
                type="text"
                placeholder="TIA ou RA"
                value={usuario}
                onChange={(e) => setUsuario(e.target.value)}
              />
            </div>
            <div className="input-container">
              <input
                type="password"
                placeholder="Senha"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
              />
            </div>
            {modo === 'cadastrar' && (
              <div className="input-container">
                <input
                  type="password"
                  placeholder="Confirmar Senha"
                  value={confirmarSenha}
                  onChange={(e) => setConfirmarSenha(e.target.value)}
                />
              </div>
            )}
            <div className="button-group">
              <button onClick={realizarAcao}>
                {modo === 'entrar' ? 'Entrar' : 'Cadastrar'}
              </button>
            </div>
            {mensagem && <p>{mensagem}</p>}
            <p onClick={alternarModo}>
              {modo === 'entrar'
                ? 'Criar uma conta'
                : 'Já tem uma conta? Entrar'}
            </p>
            </div>
          </div>
      )}
    </div>
  );
}

export default App;